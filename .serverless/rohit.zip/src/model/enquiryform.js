const mongoose = require('mongoose'); 
//const objectId=mongoose.Schema.Types.ObjectId

const enquirySchema   = mongoose.Schema({
    name: {type: String  },
    email:{type:String},
    phone:{type:String},
    State:{type:String},
    Country:{type:String},
    Expected_Date_of_Arrival:{type:String},
    Expected_Date_of_Departure:{type:String},
    Grown_Ups_Above_13_years:{type:String},
    Children_5_13_years:{type:String},
    Infants_upto_5_years:{type:String},
    How_important_is_service_to_you:{type:String},
    Message:{type:String},
})
const enquiryModel = mongoose.model('enquiryform', enquirySchema); 
module.exports = enquiryModel;