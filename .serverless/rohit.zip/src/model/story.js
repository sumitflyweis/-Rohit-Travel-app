// const mongoose = require('mongoose');
// const objectId=mongoose.Schema.Types.ObjectId

// const storySchema = mongoose.Schema({
//     title: String,
//  });

// const Story = mongoose.model('Story', storySchema);
// module.exports = Story;