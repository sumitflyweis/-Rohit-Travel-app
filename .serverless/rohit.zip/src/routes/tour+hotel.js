// const express = require('express'); 
// const {tourProfile,tourProfile1,gettour2,gettour,Updatetour,deletetour,advanceSearchFilter} = require('../controller/admin/tour+hotel');
//const verifyAdmin = require('../middleware/isAdmin')
//const verifyToken = require('../middleware/auth_check');

// const tourHotelRouter = express.Router();
 

// tourHotelRouter.post('/create', tourProfile);
// tourHotelRouter.post('/create1', tourProfile1);
// tourHotelRouter.get('/gettour2',gettour2);
// tourHotelRouter.get('/gettour',gettour);
// tourHotelRouter.put('/update/:id',Updatetour);
// tourHotelRouter.delete('/delete/:id',deletetour);
// tourHotelRouter.get('/advanceSearchFilter/:id',advanceSearchFilter);


  
// module.exports = tourHotelRouter;